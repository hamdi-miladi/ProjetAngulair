import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [{ path: 'users', loadChildren: () => import('./core/layout/users/users.module').then(m => m.UsersModule) }, { path: 'projects', loadChildren: () => import('./core/layout/projects/projects.module').then(m => m.ProjectsModule) }, { path: 'tosks', loadChildren: () => import('./core/layout/tosks/tosks.module').then(m => m.TosksModule) }, { path: 'statistiques', loadChildren: () => import('./core/layout/statistiques/statistiques.module').then(m => m.StatistiquesModule) }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
