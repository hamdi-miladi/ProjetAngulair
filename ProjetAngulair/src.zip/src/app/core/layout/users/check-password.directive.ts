import { Directive } from '@angular/core';

@Directive({
  selector: '[appCheckPassword]'
})
export class CheckPasswordDirective {

  constructor() { }

}
