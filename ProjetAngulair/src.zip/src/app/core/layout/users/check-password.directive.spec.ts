import { CheckPasswordDirective } from './check-password.directive';

describe('CheckPasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckPasswordDirective();
    expect(directive).toBeTruthy();
  });
});
