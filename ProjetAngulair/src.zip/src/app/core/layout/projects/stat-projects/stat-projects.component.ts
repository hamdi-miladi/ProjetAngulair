import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stat-projects',
  templateUrl: './stat-projects.component.html',
  styleUrls: ['./stat-projects.component.css']
})
export class StatProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
