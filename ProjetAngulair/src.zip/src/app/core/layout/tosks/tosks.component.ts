import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tosks',
  templateUrl: './tosks.component.html',
  styleUrls: ['./tosks.component.css']
})
export class TosksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
