import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kanban-tasks',
  templateUrl: './kanban-tasks.component.html',
  styleUrls: ['./kanban-tasks.component.css']
})
export class KanbanTasksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
