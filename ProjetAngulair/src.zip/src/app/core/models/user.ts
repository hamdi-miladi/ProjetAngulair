export class User {
  constructor(public username: string,
              public password: string,
              public lastname: string,
              public firstname: string,
              public email: string,
              public role: string) {
  }
}
